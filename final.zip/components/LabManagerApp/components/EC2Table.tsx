"use client"

import type React from "react"
import { useState, useCallback, useMemo, useEffect } from "react"
import axios from "axios"
import { RefreshCcw, Copy, Eye, EyeOff, Loader2 } from "lucide-react"

import { usePasswordState } from "./password-management/usePasswordState"
import PasswordModal from "./password-management/PasswordModal"
import ClusterConfigModal from "./modals/ClusterConfigModal"
import ExtendValidityModal from "./modals/ExtendValidityModal"
import InstallSplunkModal from "./modals/InstallSplunkModal"
import BulkActions from "./actions/BulkActions"
import ClusterActions from "./actions/ClusterActions"
import ServiceTable from "./table/ServiceTable"
import { useInstanceActions } from "./actions/useInstanceActions"
import { MAX_PASSWORD_CLICKS } from "./password-management/password-storage"
import type { EC2Instance, ClusterInstance, SplunkValidationResult } from "./types"

interface EC2TableProps {
  email: string
  instances: EC2Instance[]
  setInstances: (instances: EC2Instance[]) => void
  loading: boolean
  rawUsageSummary: any[]
  fetchUsageSummary: () => void
  isRefreshingUsage: boolean
  hasLab: boolean
  onPasswordModalOpenChange?: (open: boolean) => void
}

const EC2Table: React.FC<EC2TableProps> = ({
  email,
  instances,
  setInstances,
  loading,
  rawUsageSummary,
  fetchUsageSummary,
  isRefreshingUsage,
  hasLab,
  onPasswordModalOpenChange,
}) => {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL as string

  const [copiedField, setCopiedField] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState<boolean>(false)
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({})
  const [showExpiryColumn, setShowExpiryColumn] = useState<Record<string, boolean>>({})
  const [selectedInstances, setSelectedInstances] = useState<Set<string>>(new Set())
  const [expandedUsageRows, setExpandedUsageRows] = useState<Record<string, boolean>>({})
  const [expandedCredentials, setExpandedCredentials] = useState<Record<string, boolean>>({})

  const {
    passwordModal,
    setPasswordModal,
    passwordClickCount,
    isPasswordRateLimited,
    remainingTime,
    formatRemainingTime,
    incrementPasswordClick,
  } = usePasswordState(email)

  const [clusterConfigModal, setClusterConfigModal] = useState({
    isOpen: false,
    loading: false,
    error: null as string | React.ReactNode | null,
    success: false,
    username: "",
    email: "",
    editableUsername: false,
    startingInstances: false,
    checkingLicense: false,
    licenseError: null as string | null,
    needsLicenseUpload: false,
    managementServerNotFound: false,
    stoppedInstances: [] as any[],
    splunkValidationTimer: 0,
    splunkValidationInProgress: false,
    splunkValidationResults: null as any,
    showProceedAfterTimer: false,
    splunkServerStatus: [] as Array<{
      ip: string
      status: string
      details: string
      instanceName?: string
    }>,
    showSplunkStatus: false,
    licenseValidationComplete: false,
    finalConfigurationInProgress: false,
    finalConfigurationComplete: false,
    configurationResponse: null as any,
  })

  const [clusterInstancesFreeze, setClusterInstancesFreeze] = useState({
    frozen: false,
    freezeEndTime: null as number | null,
    remainingTime: 0,
  })

  const [frozenClusterInstances, setFrozenClusterInstances] = useState<Record<string, number>>({})
  const [frozenClusterRemainingTimes, setFrozenClusterRemainingTimes] = useState<Record<string, number>>({})

  const [extendValidityModal, setExtendValidityModal] = useState({
    isOpen: false,
    instanceId: "",
    instanceName: "",
    endDate: "",
  })

  const [installSplunkModal, setInstallSplunkModal] = useState({
    isOpen: false,
  })

  const [stableTooltips, setStableTooltips] = useState<Record<string, string>>({})

  useEffect(() => {
    const defaultExpanded: Record<string, boolean> = {}
    const defaultExpandedSources = ["MYSQL", "Jenkins", "MSSQL", "OSSEC", "OpenVPN"]

    // Set default expanded state for specified data sources
    instances.forEach((inst) => {
      if (defaultExpandedSources.includes(inst.Name)) {
        defaultExpanded[inst.InstanceId] = true
      }
    })

    // Only update if there are instances and the state is different
    if (instances.length > 0) {
      setExpandedCredentials((prev) => ({
        ...prev,
        ...defaultExpanded,
      }))
    }
  }, [instances])

  // Function to get expiry date for an instance
  const getInstanceExpiryDate = (instanceId: string): string => {
    for (const summary of rawUsageSummary) {
      if (summary.InstanceIds && summary.InstanceIds.includes(instanceId)) {
        return summary.PlanEndDate || "N/A"
      }
    }
    return "N/A"
  }

  // Function to get usage details for an instance
  const getInstanceUsageDetails = (instanceId: string) => {
    for (const summary of rawUsageSummary) {
      if (summary.InstanceIds && summary.InstanceIds.includes(instanceId)) {
        return {
          quota_hours: summary.QuotaHours || 0,
          used_hours: summary.ConsumedHours || 0,
          balance_hours: summary.BalanceHours || 0,
          quota_days: summary.QuotaExpiryDays || 0,
          used_days: summary.ConsumedDays || 0,
          plan_start_date: summary.PlanStartDate || "",
          plan_end_date: summary.PlanEndDate || "",
          balance_days: summary.BalanceDays || 0,
        }
      }
    }
    return null
  }

  // Function to toggle usage details expansion
  const toggleUsageDetails = useCallback((instanceId: string) => {
    setExpandedUsageRows((prev) => ({
      ...prev,
      [instanceId]: !prev[instanceId],
    }))
  }, [])

  // Helper function to check if instances match cluster pattern
  const isClusterInstance = (instanceName: string) => {
    const clusterPatterns = ["ClusterMaster", "idx1", "idx2", "idx3", "Management_server", "IF", "SH1", "SH2", "SH3"]
    return clusterPatterns.some((pattern) => instanceName.includes(pattern))
  }

  // Helper function to extract username from instance name
  const extractUsernameFromInstance = (instanceName: string) => {
    const patterns = ["ClusterMaster", "idx1", "idx2", "idx3", "Management_server", "IF", "SH1", "SH2", "SH3"]

    for (const pattern of patterns) {
      if (instanceName.includes(`-${pattern}`)) {
        return instanceName.split(`-${pattern}`)[0]
      }
    }
    return instanceName.split("-")[0]
  }

  // Helper function to check if service type has complete cluster set
  const hasCompleteClusterSet = (serviceInstances: EC2Instance[]) => {
    const requiredPatterns = ["ClusterMaster", "idx1", "idx2", "idx3", "Management_server", "IF", "SH1", "SH2", "SH3"]

    // Get all usernames from cluster instances
    const usernames = new Set<string>()
    serviceInstances.forEach((inst) => {
      if (isClusterInstance(inst.Name)) {
        usernames.add(extractUsernameFromInstance(inst.Name))
      }
    })

    // Check if any username has all required patterns
    for (const username of usernames) {
      const userInstances = serviceInstances.filter((inst) => inst.Name.startsWith(username))
      const foundPatterns = userInstances
        .map((inst) => {
          for (const pattern of requiredPatterns) {
            if (inst.Name.includes(`-${pattern}`)) {
              return pattern
            }
          }
          return null
        })
        .filter(Boolean)

      if (requiredPatterns.every((pattern) => foundPatterns.includes(pattern))) {
        return { hasComplete: true, username }
      }
    }

    return { hasComplete: false, username: null }
  }

  // Helper function to get cluster instances for a specific username
  const getClusterInstancesForUsername = useCallback(
    (username: string) => {
      return instances.filter((inst) => inst.Name.startsWith(username) && isClusterInstance(inst.Name))
    },
    [instances],
  )

  // Helper function to check if instance is frozen
  const isInstanceFrozen = useCallback(
    (instanceId: string) => {
      const endTime = frozenClusterInstances[instanceId]
      if (!endTime) return false
      return Date.now() < endTime
    },
    [frozenClusterInstances],
  )

  // Helper function to calculate notification dot urgency
  const getNotificationUrgency = (instanceId: string) => {
    const usageDetails = getInstanceUsageDetails(instanceId)
    if (!usageDetails) return null

    const now = new Date()
    const endDate = new Date(usageDetails.plan_end_date)
    const daysUntilEnd = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
    const usagePercentage = (usageDetails.used_hours / usageDetails.quota_hours) * 100

    // Check if we should show notification (2 days before end OR 80% usage)
    const shouldShowByDate = daysUntilEnd <= 2 && daysUntilEnd >= 0
    const shouldShowByUsage = usagePercentage >= 80

    if (!shouldShowByDate && !shouldShowByUsage) return null

    // Determine urgency level
    const isHighUrgency = daysUntilEnd <= 1 || usagePercentage >= 90

    return {
      level: isHighUrgency ? "high" : "medium",
      daysUntilEnd,
      usagePercentage: Math.round(usagePercentage),
      endDate: usageDetails.plan_end_date,
    }
  }

  // Helper function to get notification tooltip text
  const getNotificationTooltip = (urgency: any) => {
    if (!urgency) return ""

    const messages = []
    if (urgency.daysUntilEnd <= 2 && urgency.daysUntilEnd >= 0) {
      messages.push(`Quota expires in ${urgency.daysUntilEnd} day${urgency.daysUntilEnd !== 1 ? "s" : ""}`)
    }
    if (urgency.usagePercentage >= 80) {
      messages.push(`${urgency.usagePercentage}% quota used`)
    }

    return `${messages.join(" • ")} - Click to extend validity`
  }

  // Helper function to handle extend validity
  const handleExtendValidity = (instanceId: string, instanceName: string) => {
    const usageDetails = getInstanceUsageDetails(instanceId)
    setExtendValidityModal({
      isOpen: true,
      instanceId,
      instanceName,
      endDate: usageDetails?.plan_end_date || "",
    })
  }

  const fetchFreshInstanceData = useCallback(async () => {
    try {
      const res = await axios.get(`${apiUrl}/instances`, {
        headers: { Authorization: `Bearer ${email}` },
      })
      return res.data
    } catch (error) {
      console.error("Error fetching instances:", error)
      return []
    }
  }, [apiUrl, email])

  const fetchInstances = useCallback(async () => {
    try {
      setRefreshing(true)
      const res = await axios.get(`${apiUrl}/instances`, {
        headers: { Authorization: `Bearer ${email}` },
      })
      setInstances(res.data)
    } catch (error) {
      console.error("Error fetching instances:", error)
    } finally {
      setRefreshing(false)
    }
  }, [apiUrl, email, setInstances])

  const {
    disabledButtons,
    loadingAction,
    bulkActionLoading,
    cooldowns,
    handleButtonClick,
    handleBulkAction,
    callAction,
  } = useInstanceActions(email, instances, fetchInstances, isInstanceFrozen)

  const validateSplunkInstallation = useCallback(
    async (username: string) => {
      try {
        // Get fresh instance data
        const freshInstances: ClusterInstance[] = await fetchFreshInstanceData()

        const clusterInstances = freshInstances.filter(
          (inst: ClusterInstance) => inst.Name && inst.Name.toLowerCase().includes(username.toLowerCase()),
        )

        const runningInstances = clusterInstances.filter(
          (inst: ClusterInstance) => inst.State && inst.State.toLowerCase() === "running",
        )

        if (runningInstances.length === 0) {
          const currentStates = clusterInstances
            .map((inst: ClusterInstance) => `${inst.Name}: ${inst.State}`)
            .join(", ")
          throw new Error(`No running servers found for Splunk validation. Current states: ${currentStates}`)
        }

        const publicIps: string[] = []
        const serverDetails: { name: string; ip: string | null }[] = []

        runningInstances.forEach((inst: ClusterInstance) => {
          // Try all possible property names for public IP
          const possibleIpProps = [
            "PublicIpAddress",
            "PublicIP",
            "Public IP",
            "publicIp",
            "public_ip",
            "PublicIp",
            "public_ip_address",
            "publicIpAddress",
            "ip",
            "IP",
          ]

          let publicIp: string | null = null

          for (const prop of possibleIpProps) {
            if (inst[prop] && typeof inst[prop] === "string" && inst[prop].trim()) {
              publicIp = inst[prop].trim()
              break
            }
          }

          // If still no IP found, check if it's nested in an object
          if (!publicIp && typeof inst === "object") {
            const allKeys = Object.keys(inst)

            // Look for any property that might contain an IP address pattern
            for (const key of allKeys) {
              const value = inst[key]
              if (typeof value === "string" && /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(value)) {
                publicIp = value
                break
              }
            }
          }

          serverDetails.push({ name: inst.Name || "Unknown", ip: publicIp })

          if (publicIp) {
            publicIps.push(publicIp)
          }
        })

        if (publicIps.length === 0) {
          const serverNames = runningInstances.map((inst: ClusterInstance) => inst.Name).join(", ")
          throw new Error(
            `No public IPs found for running servers: ${serverNames}. Please check if instances have public IP addresses assigned.`,
          )
        }

        const response = await fetch("/api/lab-proxy", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-user-email": email,
          },
          body: JSON.stringify({
            path: "/splunk-validate",
            method: "POST",
            body: {
              public_ips: publicIps,
            },
          }),
        })

        if (!response.ok) {
          throw new Error(`Splunk validation API failed: ${response.status} ${response.statusText}`)
        }

        const data = await response.json()

        const results = data.results || []
        const enhancedResults = results.map((result: SplunkValidationResult) => {
          const serverDetail = serverDetails.find((s) => s.ip === result.ip)
          return {
            ...result,
            serverName: serverDetail?.name || `Server (${result.ip})`,
          }
        })

        return {
          success: true,
          results: enhancedResults,
          instances: runningInstances,
        }
      } catch (error) {
        console.error("Splunk validation error:", error)
        throw error
      }
    },
    [email, fetchFreshInstanceData],
  )

  const validateSplunkLicense = useCallback(
    async (username: string) => {
      try {
        // Find the Management_server instance
        const managementServer = instances.find(
          (inst) => inst.Name.includes(`${username}-Management_server`) && inst.ServiceType === "Splunk",
        )

        if (!managementServer || !managementServer.PublicIp) {
          throw new Error("Management server not found or doesn't have a public IP")
        }

        // Check if Management_server is running
        if (managementServer.State !== "running") {
          throw new Error("Management server is not running. Please start it first.")
        }

        // Use our backend proxy to handle HTTPS certificate issues
        const response = await fetch("/api/lab-proxy", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-user-email": email,
          },
          body: JSON.stringify({
            path: "/validate-splunk-license",
            method: "POST",
            body: {
              management_server_ip: managementServer.PublicIp,
              username: "admin",
              password: "admin123",
            },
          }),
        })

        if (!response.ok) {
          throw new Error(`Failed to connect to Management server: ${response.status}`)
        }

        const data = await response.json()

        if (data.message === "Internal Server Error") {
          return {
            valid: false,
            error: "Public IP not correct. Please try again.",
          }
        }

        if (data.status === "Splunk License updated") {
          return {
            valid: true,
            message: "Splunk license updated successfully",
          }
        }

        if (data.status === "Splunk Enterprise Trial free account") {
          return {
            valid: false,
            needsLicenseUpload: true,
            message: (
              <>
                Splunk license update required. Please update the license in the Management_server.
                <button
                  onClick={() => setInstallSplunkModal({ isOpen: true })}
                  className="ml-2 text-blue-600 underline text-xs"
                >
                  Read more
                </button>
              </>
            ),
          }
        }

        // For any other status, assume license needs to be uploaded
        return {
          valid: false,
          needsLicenseUpload: true,
          message: "License validation failed. Please check your license configuration.",
        }
      } catch (error) {
        console.error("License validation error:", error)
        throw error
      }
    },
    [instances, email],
  )

  const handleCopy = useCallback((text: string, fieldId: string) => {
    navigator.clipboard.writeText(text)
    setCopiedField(fieldId)
    setTimeout(() => setCopiedField(null), 1500)
  }, [])

  const renderCopyField = (text: string, fieldId: string, truncate?: boolean) => {
    const displayText = truncate && text.length > 25 ? text.substring(0, 25) + "..." : text
    return (
      <div className="relative inline-flex items-center">
        <span className="mr-1.5">{displayText}</span>
        <div
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
            handleCopy(text, fieldId)
          }}
          className="cursor-pointer p-0.5 rounded-md flex items-center justify-center bg-gray-100 border border-gray-200 hover:bg-gray-200 hover:text-gray-700 transition-colors duration-200"
        >
          <Copy size={14} className="text-gray-500" />
        </div>
        {copiedField === fieldId && (
          <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-green-500 text-white text-xs px-2 py-1 rounded-md whitespace-nowrap animate-in fade-in-0 zoom-in-95 slide-in-from-bottom-1 duration-200">
            Copied!
          </div>
        )}
      </div>
    )
  }

  const baseStyle: React.CSSProperties = {
    padding: "6px 14px",
    fontSize: "0.85rem",
    borderRadius: "6px",
    border: "none",
    cursor: "pointer",
    transition: "all 0.2s ease",
    fontFamily: "Inter, sans-serif",
    color: "white",
    whiteSpace: "nowrap",
  }

  const actionStyles: Record<string, { backgroundColor: string; hover: string }> = {
    start: {
      backgroundColor: "#10b981",
      hover: "#059669",
    },
    stop: {
      backgroundColor: "#ef4444",
      hover: "#dc2626",
    },
    reboot: {
      backgroundColor: "#f59e0b",
      hover: "#d97706",
    },
    "get-password": {
      backgroundColor: "#3b82f6",
      hover: "#2563eb",
    },
  }

  const isCooldown = (instanceId: string, action: string) =>
    disabledButtons[`${instanceId}_${action}`] || isInstanceFrozen(instanceId)

  const getButtonTooltip = (action: string, instanceId: string, instanceName: string) => {
    const isFrozen = isInstanceFrozen(instanceId)

    if (isFrozen) {
      return `Cluster configuration in progress. Please wait until the runtime is complete.`
    }

    const disabled = isCooldown(instanceId, action)
    if (disabled) {
      const cooldownKey = `${instanceId}_${action}`
      const remainingTime = cooldowns[cooldownKey] || 0
      return `Please wait ${remainingTime}s before ${action}ing again`
    }

    return `${action.charAt(0).toUpperCase() + action.slice(1)} ${instanceName || instanceId}`
  }

  const getBulkButtonTooltip = useCallback(
    (action: string) => {
      const frozenSelected = Array.from(selectedInstances).filter((id) => isInstanceFrozen(id))

      if (frozenSelected.length > 0) {
        return "Cluster configuration is in progress. Please wait until the runtime is complete."
      }

      if (selectedInstances.size === 0) {
        return `Select servers to perform bulk ${action}`
      }

      return `${action.charAt(0).toUpperCase() + action.slice(1)} all selected servers`
    },
    [selectedInstances, isInstanceFrozen],
  )

  const renderButton = (label: string, action: string, instanceId: string, instanceName = "") => {
    const key = `${instanceId}_${action}`
    const disabled = isCooldown(instanceId, action)
    const isLoading = loadingAction === key
    const isFrozen = isInstanceFrozen(instanceId)

    const isButtonDisabled = disabled || isFrozen

    return (
      <button
        onClick={(e) => {
          e.preventDefault()
          e.stopPropagation()
          if (!isFrozen && !disabled) {
            handleButtonClick(action, instanceId)
          }
        }}
        style={{
          ...baseStyle,
          backgroundColor: isButtonDisabled ? "#9ca3af" : actionStyles[action].backgroundColor,
          cursor: isButtonDisabled ? "not-allowed" : "pointer",
          opacity: isButtonDisabled ? 0.6 : 1,
          display: "inline-flex",
          alignItems: "center",
          gap: "6px",
        }}
        disabled={isButtonDisabled}
        title={getButtonTooltip(action, instanceId, instanceName)}
        onMouseEnter={(e) => {
          if (!isButtonDisabled) {
            ;(e.target as HTMLButtonElement).style.backgroundColor = actionStyles[action].hover
          }
        }}
        onMouseLeave={(e) => {
          if (!isButtonDisabled) {
            ;(e.target as HTMLButtonElement).style.backgroundColor = actionStyles[action].backgroundColor
          }
        }}
      >
        {isLoading ? (
          <Loader2 size={14} className="animate-spin" />
        ) : isFrozen ? (
          formatRemainingTime(frozenClusterRemainingTimes[instanceId] || 0)
        ) : (
          label
        )}
      </button>
    )
  }

  const handleGetPassword = useCallback(
    async (instanceId: string) => {
      if (isPasswordRateLimited) {
        console.warn("Password retrieval limit reached. Please wait for the next 20-minute window.")
        return
      }

      if (passwordModal.loading) {
        return
      }

      incrementPasswordClick()

      setPasswordModal((prev) => ({
        ...prev,
        isOpen: true,
        loading: true,
        error: null,
        details: null,
      }))
      onPasswordModalOpenChange?.(true)

      const instance = instances.find((inst) => inst.InstanceId === instanceId)
      if (!instance) {
        setPasswordModal((prev) => ({
          ...prev,
          loading: false,
          error: "Instance not found",
        }))
        return
      }

      try {
        const response = await axios.post(
          "/api/win-pass",
          {
            instance_id: instanceId,
            email: email,
          },
          {
            headers: { "Content-Type": "application/json" },
          },
        )

        if (response.data.status === "success" && response.data.decrypted_password) {
          setPasswordModal((prev) => ({
            ...prev,
            loading: false,
            error: null,
            details: {
              username: "Administrator",
              password: response.data.decrypted_password,
              publicIp: instance.PublicIp,
            },
          }))
        } else {
          setPasswordModal((prev) => ({
            ...prev,
            loading: false,
            error: response.data.message || "Failed to retrieve password.",
            details: null,
          }))
        }
      } catch (error) {
        console.error("Error fetching Windows password:", error)
        setPasswordModal((prev) => ({
          ...prev,
          loading: false,
          error: "An error occurred while fetching the password. Please try again.",
          details: null,
        }))
      }
    },
    [
      isPasswordRateLimited,
      passwordModal.loading,
      email,
      instances,
      onPasswordModalOpenChange,
      incrementPasswordClick,
      setPasswordModal,
    ],
  )

  const toggleExpiryColumn = useCallback((serviceType: string) => {
    setShowExpiryColumn((prev) => ({
      ...prev,
      [serviceType]: !prev[serviceType],
    }))
  }, [])

  const handleInstanceSelection = useCallback((instanceId: string, checked: boolean) => {
    setSelectedInstances((prev) => {
      const newSet = new Set(prev)
      if (checked) {
        newSet.add(instanceId)
      } else {
        newSet.delete(instanceId)
      }
      return newSet
    })
  }, [])

  const handleSelectAllForServiceType = useCallback(
    (serviceType: string, checked: boolean) => {
      const serviceInstances = groupedInstances[serviceType]
      setSelectedInstances((prev) => {
        const newSet = new Set(prev)
        serviceInstances.forEach((instance) => {
          if (checked) {
            newSet.add(instance.InstanceId)
          } else {
            newSet.delete(instance.InstanceId)
          }
        })
        return newSet
      })
    },
    [instances],
  )

  const handleKeepOnlyRunning = useCallback(() => {
    setSelectedInstances((prev) => {
      const newSet = new Set<string>()
      Array.from(prev).forEach((instanceId) => {
        const instance = instances.find((inst) => inst.InstanceId === instanceId)
        if (instance && instance.State === "running") {
          newSet.add(instanceId)
        }
      })
      return newSet
    })
  }, [instances])

  const handleKeepOnlyStopped = useCallback(() => {
    setSelectedInstances((prev) => {
      const newSet = new Set<string>()
      Array.from(prev).forEach((instanceId) => {
        const instance = instances.find((inst) => inst.InstanceId === instanceId)
        if (instance && instance.State === "stopped") {
          newSet.add(instanceId)
        }
      })
      return newSet
    })
  }, [instances])

  const groupedInstances = useMemo(() => {
    return instances.reduce<Record<string, EC2Instance[]>>((acc, inst) => {
      const key = inst.ServiceType || "Unknown"
      if (!acc[key]) acc[key] = []
      acc[key].push(inst)
      return acc
    }, {})
  }, [instances])

  const orderedServiceTypes = Object.keys(groupedInstances).sort((a, b) => {
    if (a === "Splunk") return -1
    if (b === "Splunk") return 1
    return 0
  })

  const selectedInstanceDetails = Array.from(selectedInstances)
    .map((id) => instances.find((inst) => inst.InstanceId === id))
    .filter(Boolean) as EC2Instance[]

  const allSelectedStopped =
    selectedInstanceDetails.length > 0 && selectedInstanceDetails.every((inst) => inst.State === "stopped")
  const allSelectedRunning =
    selectedInstanceDetails.length > 0 && selectedInstanceDetails.every((inst) => inst.State === "running")
  const hasMixedStates = selectedInstances.size > 0 && !allSelectedStopped && !allSelectedRunning

  const formatFloatHours = (hours: number): string => {
    const h = Math.floor(hours)
    const m = Math.round((hours - h) * 60)
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}`
  }

  const toggleCredentialExpansion = useCallback((instanceId: string) => {
    setExpandedCredentials((prev) => ({
      ...prev,
      [instanceId]: !prev[instanceId],
    }))
  }, [])

  return (
    <div style={{ marginTop: 20 }}>
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-semibold text-gray-800"></h2>
        <button
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
            fetchInstances()
          }}
          disabled={refreshing}
          className={`p-2 rounded-full ${
            refreshing ? "bg-gray-400 cursor-not-allowed" : "bg-amber-500 hover:bg-amber-600 text-gray-700"
          } text-white`}
          title="Refresh"
        >
          <RefreshCcw className={`w-4 h-4 ${refreshing ? "animate-spin" : ""}`} />
        </button>
      </div>

      {instances.length === 0 && !loading ? (
        <div className="text-center py-16">
          <div className="max-w-md mx-auto bg-white border border-gray-200 shadow-lg rounded-2xl p-8">
            <h3 className="text-2xl font-semibold text-gray-800 mb-3">You don't have any servers here.</h3>
            <div className="bg-blue-50 border border-gray-200 rounded-lg p-4 mb-6">
              <p className="text-gray-700 text-sm leading-relaxed">
                It looks like you don't have a lab assigned yet. Choose a plan to get started with your personalized lab
                setup.
              </p>
            </div>
            <button
              onClick={(e) => {
                e.preventDefault()
                e.stopPropagation()
                window.location.href = "/"
              }}
              className="w-full bg-green-600 hover:bg-green-700 transition-colors text-white font-medium py-3 px-6 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              Choose Lab Plan
            </button>
          </div>
        </div>
      ) : (
        <>
          <BulkActions
            selectedInstances={selectedInstances}
            selectedInstanceDetails={selectedInstanceDetails}
            bulkActionLoading={bulkActionLoading}
            allSelectedStopped={allSelectedStopped}
            allSelectedRunning={allSelectedRunning}
            hasMixedStates={hasMixedStates}
            isInstanceFrozen={isInstanceFrozen}
            onBulkAction={(action: string) => handleBulkAction(action, selectedInstances)}
            onKeepOnlyRunning={handleKeepOnlyRunning}
            onKeepOnlyStopped={handleKeepOnlyStopped}
            getBulkButtonTooltip={getBulkButtonTooltip}
          />

          {orderedServiceTypes.map((serviceType) => {
            const serviceInstances = groupedInstances[serviceType]
            const allUsageRowsExpanded = serviceInstances.every((inst) => expandedUsageRows[inst.InstanceId])

            return (
              <div key={serviceType} style={{ marginBottom: 40 }}>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-md font-semibold text-green-600">
                    {serviceType} Servers
                    {serviceType === "Splunk" && (
                      <span className="text-gray-500 text-sm font-normal ml-2">
                        (username: admin, password: admin123)
                      </span>
                    )}
                  </h3>
                  <div className="flex flex-wrap items-center gap-2">
                    <ClusterActions
                      serviceType={serviceType}
                      serviceInstances={serviceInstances}
                      hasCompleteClusterSet={hasCompleteClusterSet}
                      onClusterConfiguration={async (instances: EC2Instance[]) => {
                        const clusterInfo = hasCompleteClusterSet(instances)
                        if (!clusterInfo.hasComplete || !clusterInfo.username) return

                        setClusterConfigModal({
                          isOpen: true,
                          loading: false,
                          error: null,
                          success: false,
                          username: clusterInfo.username,
                          email: email,
                          editableUsername: false,
                          startingInstances: false,
                          checkingLicense: false,
                          licenseError: null,
                          needsLicenseUpload: false,
                          managementServerNotFound: false,
                          stoppedInstances: [],
                          splunkValidationTimer: 0,
                          splunkValidationInProgress: false,
                          splunkValidationResults: null,
                          showProceedAfterTimer: false,
                          splunkServerStatus: [],
                          showSplunkStatus: false,
                          licenseValidationComplete: false,
                          finalConfigurationInProgress: false,
                          finalConfigurationComplete: false,
                          configurationResponse: null,
                        })
                      }}
                    />

                    <button
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        toggleExpiryColumn(serviceType)
                      }}
                      className="flex items-center gap-1 sm:gap-2 px-2 sm:px-3 py-1 text-xs sm:text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
                      title={`${showExpiryColumn[serviceType] ? "Hide" : "Show"} Expiry`}
                    >
                      {showExpiryColumn[serviceType] ? (
                        <EyeOff size={14} className="sm:w-4 sm:h-4" />
                      ) : (
                        <Eye size={14} className="sm:w-4 sm:h-4" />
                      )}
                      <span>Expiry</span>
                    </button>
                    <button
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        const newState = !allUsageRowsExpanded
                        serviceInstances.forEach((inst) => {
                          setExpandedUsageRows((prev) => ({
                            ...prev,
                            [inst.InstanceId]: newState,
                          }))
                        })
                      }}
                      className="flex items-center gap-1 sm:gap-2 px-2 sm:px-3 py-1 text-xs sm:text-sm bg-blue-100 hover:bg-blue-200 rounded-md transition-colors"
                      title="Toggle Usage Details"
                    >
                      {allUsageRowsExpanded ? (
                        <EyeOff size={14} className="sm:w-4 sm:h-4 transition-transform duration-300" />
                      ) : (
                        <Eye size={14} className="sm:w-4 sm:h-4 transition-transform duration-300" />
                      )}
                      <span className="hidden sm:inline">More Details</span>
                      <span className="sm:hidden">Details</span>
                    </button>
                  </div>
                </div>

                <div
                  style={{
                    overflowX: "auto",
                    width: "100%",
                    borderRadius: 8,
                    border: "1px solid #e2e8f0",
                  }}
                >
                  <ServiceTable
                    serviceType={serviceType}
                    instances={serviceInstances}
                    showExpiryColumn={showExpiryColumn[serviceType]}
                    selectedInstances={selectedInstances}
                    expandedCredentials={expandedCredentials}
                    expandedUsageRows={expandedUsageRows}
                    disabledButtons={disabledButtons}
                    loadingAction={loadingAction}
                    copiedField={copiedField}
                    passwordModal={passwordModal}
                    isPasswordRateLimited={isPasswordRateLimited}
                    passwordClickCount={passwordClickCount}
                    remainingTime={remainingTime}
                    onSelectAll={handleSelectAllForServiceType}
                    onInstanceSelection={handleInstanceSelection}
                    onToggleCredentials={toggleCredentialExpansion}
                    onToggleUsageDetails={toggleUsageDetails}
                    onAction={handleButtonClick}
                    onGetPassword={handleGetPassword}
                    onExtendValidity={handleExtendValidity}
                    renderCopyField={renderCopyField}
                    renderButton={renderButton}
                    getInstanceExpiryDate={getInstanceExpiryDate}
                    getInstanceUsageDetails={getInstanceUsageDetails}
                    getNotificationUrgency={getNotificationUrgency}
                    getNotificationTooltip={getNotificationTooltip}
                    formatRemainingTime={formatRemainingTime}
                    formatFloatHours={formatFloatHours}
                    fetchUsageSummary={fetchUsageSummary}
                    isRefreshingUsage={isRefreshingUsage}
                    MAX_PASSWORD_CLICKS={MAX_PASSWORD_CLICKS}
                  />
                </div>
              </div>
            )
          })}
        </>
      )}

      <PasswordModal
        passwordModal={passwordModal}
        setPasswordModal={setPasswordModal}
        isPasswordRateLimited={isPasswordRateLimited}
        remainingTime={remainingTime}
        formatRemainingTime={formatRemainingTime}
        copiedField={copiedField}
        setCopiedField={setCopiedField}
      />

      <ClusterConfigModal
        clusterConfigModal={clusterConfigModal}
        setClusterConfigModal={setClusterConfigModal}
        clusterInstancesFreeze={clusterInstancesFreeze}
        formatRemainingTime={formatRemainingTime}
        onSubmit={async () => {
          // Handle cluster config submit logic
        }}
        onClose={() => {
          setClusterConfigModal({
            isOpen: false,
            loading: false,
            error: null,
            success: false,
            username: "",
            email: "",
            editableUsername: false,
            startingInstances: false,
            checkingLicense: false,
            licenseError: null,
            needsLicenseUpload: false,
            managementServerNotFound: false,
            stoppedInstances: [],
            splunkValidationTimer: 0,
            splunkValidationInProgress: false,
            splunkValidationResults: null,
            showProceedAfterTimer: false,
            splunkServerStatus: [],
            showSplunkStatus: false,
            licenseValidationComplete: false,
            finalConfigurationInProgress: false,
            finalConfigurationComplete: false,
            configurationResponse: null,
          })
        }}
        onRetryValidation={async () => {
          // Handle retry validation logic
        }}
        onProceedToLicense={async () => {
          // Handle proceed to license logic
        }}
        onTriggerConfiguration={async () => {
          // Handle trigger configuration logic
        }}
        setInstallSplunkModal={setInstallSplunkModal}
      />

      <ExtendValidityModal extendValidityModal={extendValidityModal} setExtendValidityModal={setExtendValidityModal} />

      <InstallSplunkModal installSplunkModal={installSplunkModal} setInstallSplunkModal={setInstallSplunkModal} />
    </div>
  )
}

export default EC2Table
